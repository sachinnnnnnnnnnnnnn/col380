#include <iostream>
#include <vector>
#include <cmath>

#include <omp.h>
#include <chrono>



using namespace std;

double* a;
double* l;
double* u;
int n=5;
int thread_rank = 0;
int thread_count=1;

struct swap_args{
    int k_args;
    int k1_args;
};


void* swap_a(void* arg){
    #pragma omp parallel
    
    {
    
    swap_args* swap_struct = static_cast<swap_args*>(arg);
    int k1 = swap_struct->k1_args;

    int k = swap_struct->k_args;
    for(int i=0 ; i<n ; i++)
    {
        double temp1 = a[k*n + i];
        a[k*n + i] = a[k1*n + i];
        a[k1*n + i] = temp1;
    }
    
    
    }
    return nullptr;
}

void* swap_l(void* arg){
    #pragma omp parallel
    {
    
    swap_args* swap_struct = static_cast<swap_args*>(arg);
    int k = swap_struct->k_args;
    int k1 = swap_struct->k1_args;
    
    for(int i=0 ; i<k ; i++)
    {
        double temp2 = l[k*n + i];
        l[k*n + i] = l[k1*n + i];
        l[k1*n + i] = temp2;
    }
    }
    
    
    return nullptr;
}

void LU_decom_pivot(vector<vector<double>>& A,vector<vector<double>>& L,vector<vector<double>>& U,vector<int>& pi){
     int  n=A.size();
     for (int i=0;i<n;i++){
        pi[i]=i;
        // L[i][i]=1;
     }
     for (int k=0;k<n;k++){
        double maxim=0;
        int k1=-1;

        // cout<<"K=="<<k<<endl;
        for (int i=k;i<n;i++){
            if (maxim<fabs(A[i][k])){
               maxim=fabs(A[i][k]);
               k1=i;
            }
            // cout<<"I1=="<<i<<" ";

        }
        // cout<<endl;

        if (maxim==0.0){
                cout<<"Error:Singular matrix"<<endl;
                return;
            }
        int temp=pi[k];
        pi[k]=pi[k1];
        pi[k1]=temp;

        vector<double> temp1=A[k];
        A[k]=A[k1];
        A[k1]=temp1;


        for (int j=0;j<k;j++){
            
            double temp2=L[k][j];
            L[k][j]=L[k1][j];
            L[k1][j]=temp2;
            // cout<<"J1=="<<j<<" ";
        }

        
        U[k][k]=A[k][k];

        for (int i=k+1;i<n;i++){
            L[i][k]=A[i][k]/U[k][k];
            U[k][i]=A[k][i];
            // cout<<"I2=="<<i<<" ";
        }
        // cout<<endl;

        for (int i=k;i<n;i++){
            for (int j=k;j<n;j++){
                // cout<<"I,J=="<<i<<","<<j<<" ";
                A[i][j]=A[i][j]-L[i][k]*U[k][j];
            }
            // cout<<endl;
        }

     }
}



void LU_decom_ll(vector<int>& pi){
    for(int k=0 ; k<n ; k++)
    {
    
        double maxim = 0.0;
        int k1 = -1;
        omp_set_num_threads(thread_count);
        #pragma omp for
        for(int i=k; i<n ; i++)
        {
            if(maxim < fabs(a[i*n + k]))
            {
                maxim = fabs(a[i*n + k]);
                k1 = i;
            }
        }
        
        if(maxim==0.0)
        {
            cout<<"Error:Singular matrix"<<endl;
                return;
            
        
        }

        
        int temp0 = pi[k];
        pi[k] = pi[k1];
        pi[k1] = temp0;

        
        swap_args *swap_struct;
        swap_struct = (swap_args*)malloc(sizeof(swap_args));
        swap_struct->k_args = k;
        swap_struct->k1_args = k1;
        
        omp_set_num_threads(2);
        #pragma omp parallel sections
        {
            #pragma omp section
            {
                swap_a((void*)swap_struct);
            }
            #pragma omp section
            {
                swap_l((void*)swap_struct);
            }
        }


        

        u[k*n + k] = a[k*n + k];

        
        for(int i=k+1 ; i<n ; i++)
        {
            l[i*n + k] = a[i*n + k] / u[k*n + k];
            u[k*n + i] = a[k*n + i];
        }

        
        omp_set_num_threads(thread_count);

        #pragma omp for
        for (int i=k;i<n;i++){
            for (int j=k;j<n;j++){
                // cout<<"I,J=="<<i<<","<<j<<" ";
                a[i*n + j] -= l[i*n + k] * u[k*n + j];
            }
            // cout<<endl;
        }

       
        

       
    }
}
double euclideanNorm(double* matrix, int size) {
    double sumOfSquares = 0.0;

    
    for (int i = 0; i < size; ++i) {
        sumOfSquares += matrix[i] * matrix[i];
    }

    
    return std::sqrt(sumOfSquares);
}
double euclideanNorm_vec(vector<vector<double>>& A) {
    double sumOfSquares = 0.0;

    
    for (auto row : A) {
        for(auto element:row){
        sumOfSquares += element * element;
        }
    }

   
    return std::sqrt(sumOfSquares);
}

void printMatrix(double* matrix, int dim, string msg)
{
    cout << endl;
    cout << msg << endl;
    for(int i=0 ; i<dim ; i++)
    {
        for(int j=0 ; j<dim ; j++)
        {
            printf("%f ", matrix[i*dim + j]);
        }
        cout<<endl;
    }
}


int main(int argc, char *argv[]){

    

    n = stoi(argv[1]);

    thread_count=stoi(argv[2]);

    
    vector<vector<double>> L(n,vector<double>(n,0.0)), U(n,vector<double>(n,0.0)),A(n,vector<double>(n,0.0));

    a = (double*)malloc(sizeof(double)*(n*n));
    l = (double*)malloc(sizeof(double)*(n*n));
    u = (double*)malloc(sizeof(double)*(n*n));

    for (int i=0 ; i<n ; i++)
    {
       for (int j=0 ; j<n ; j++)
       {
            
            a[i*n + j] = double(rand()%(10*n))/10.0;
            A[i][j]= a[i*n + j];
            if(j>i){
               u[i*n + j] = a[i*n + j];
               U[i][j]=A[i][j];
               l[i*n + j] = 0.0;
               }
            else if(j==i){
               u[i*n + j] = a[i*n + j];
               U[i][j]=A[i][j];
               l[i*n + j] = 1.0;
               L[i][j]=1.0;
            }
            else{
               u[i*n + j] = 0.0;
               l[i*n + j] = a[i*n + j];
               L[i][j]=A[i][j];
            }
        }
    }

    vector<int> pi_1(n,0),pi_2(n,0);
    
     auto start_time = std::chrono::high_resolution_clock::now();

    LU_decom_pivot(A,L,U,pi_1);
    auto end_time = std::chrono::high_resolution_clock::now();
    auto duration = std::chrono::duration_cast<std::chrono::microseconds>(end_time - start_time);

    cout<<"Time for Sequential:"<<duration.count()<<"microseconds"<<endl;
    
    for(int i=0;i<n;i++){
        pi_2[i]=i;
    }
    start_time=std::chrono::high_resolution_clock::now();
    LU_decom_ll(pi_2);
    end_time=std::chrono::high_resolution_clock::now();
    duration = std::chrono::duration_cast<std::chrono::microseconds>(end_time - start_time);
    cout<<"Time with "<<thread_count<<" thread:"<<duration.count()<<"microseconds"<<endl;

    cout<<"L2 norm for A:"<<euclideanNorm_vec(A)<<endl;
    cout<<"L2 norm for a:"<<euclideanNorm(a,n*n)<<endl;
    // cout<<"Residul matrix for sequential"<<endl;
    // for(auto row:A){
    //     for (auto elem:row){
    //         printf("%f ",elem)
    //     }
    //     cout<<endl;
    // }
    // printMatrix(a, n, "Residual_matrix for pthread");
    
//     cout<<"Lower Triangular"<<endl;

//     for(auto row:L){
//         for (auto elem:row){
//             cout<<elem<<" ";
//         }
//         cout<<endl;
//     }


// cout<<"Upper Trianguler"<<endl;

// for(auto row:U){
//         for (auto elem:row){
//             cout<<elem<<" ";
//         }
//         cout<<endl;
//     }

    // cout<<"permutation"<<endl;

    // for (auto elem:pi_1){
    //     cout<<elem<<" ";
    // }
    // cout<<endl;

    
    // for (auto elem:pi_2){
    //     cout<<elem<<" ";
    // }
    // cout<<endl;



    return 0;
}
