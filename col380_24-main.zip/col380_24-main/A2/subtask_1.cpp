
#include <iostream>
#include <vector>
#include <cmath> // Include cmath for the tanh function

#include "subtask_1.h"
#include <bits/stdc++.h>
using namespace std;



//subtask 1 , part 3
vector<vector<float>> maxpooling(vector<vector<float>> matrix,int stride){
    int n = matrix.size()/stride;
    vector<vector<float>> out1(n,vector<float> (n,0.0f)) ;                 //out1 for maxpooling
    // vector<vector<float>> out2(n,vector<float> (n,0.0f)) ;                 //out2 for average pooling 
    for(int i=0;i<matrix.size();i+=stride){
        for(int j=0;j<matrix.size();j+=stride){
            float maxval = 0.0f;
            // float avgsum = 0.0f;
            for(int row=i;row<i+stride;row++){
                for(int col=j;col<j+stride;col++){
                    maxval=max(maxval,matrix[row][col]) ;
                    // avgsum+=matrix[row][col] ;
                }
            }
            out1[i/stride][j/stride] = maxval ;
            // out2[i/stride][j/stride] = avgsum/(stride*stride) ;
            //cout<<maxval<<endl;   
        }
    }
    return out1 ; 
}

//print matrix 
void printmatrix(vector<vector<float>> matrix){
    for(int i=0;i<matrix.size();i++){
        for(int j=0;j<matrix[0].size();j++){
            cout<<matrix[i][j]<<" ";
        }
        cout<<endl;
    }
    cout<<endl;
}

//subtask1 , part 4
//softmax function
vector<float> softmax(vector<float> vec ){
    vector<float> out ;
    float sumexp = 0.0f;
    for(auto i : vec)   sumexp+=exp(i);
    for(int i=0;i<vec.size();i++)    out.push_back(exp(vec[i])/sumexp) ;
    return out;
}


//sigmoid function
vector<float> sigmoid(vector<float> vec){
    vector<float> out ;
    for(auto i : vec)  out.push_back(1.0f/(1.0f+exp(-i)));
    return out;
}

//print vector
void printvec(vector<float> vec){
    for(int i=0;i<vec.size();i++) cout<<vec[i]<<" " ;
    cout<<endl;
}
void convolve(std::vector<std::vector<float>> input, std::vector<std::vector<float>>& output, std::vector<std::vector<float>> kernel) {
    int inputSize = input.size();
    int kernelSize = kernel.size();
    int outputSize = inputSize - kernelSize + 1;

    for (int i = 0; i < outputSize; i++) {
        for (int j = 0; j < outputSize; j++) {
            output[i][j] = 0;
            for (int m = 0; m < kernelSize; m++) {
                for (int n = 0; n < kernelSize; n++) {
                    output[i][j] += input[i + m][j + n] * kernel[m][n];
                }
            }
        }
    }
}

void convolveWithPadding(const std::vector<std::vector<float>>& input, std::vector<std::vector<float>>& output, const std::vector<std::vector<float>>& kernel) {
    int inputSize = input.size();
    int kernelSize = kernel.size();
    int padding = kernelSize / 2; // Assuming kernelSize is odd

    for (int i = 0; i < inputSize; i++) {
        for (int j = 0; j < inputSize; j++) {
            output[i][j] = 0;
            for (int m = 0; m < kernelSize; m++) {
                for (int n = 0; n < kernelSize; n++) {
                    int inputRow = (i + m - padding + inputSize) % inputSize;
                    int inputCol = (j + n - padding + inputSize) % inputSize;
                    output[i][j] += input[inputRow][inputCol] * kernel[m][n];
                }
            }
        }
    }
}

void relu(std::vector<std::vector<float>>& input) {
    for (auto& row : input) {
        for (auto& elem : row) {
            elem = elem > 0 ? elem : 0;
        }
    }
}

void applyTanh(std::vector<std::vector<float>>& input) {
    for (auto& row : input) {
        for (auto& elem : row) {
            elem = std::tanh(elem); // Corrected usage of tanh
        }
    }
}




// int main() {
//    std::vector<std::vector<float>> input = {{1, 2, 3}, {4, 5, 6}, {7, 8, 9}};
//     std::vector<std::vector<float>> kernel = {{1, 1}, {1, 1}};
//     std::vector<std::vector<float>> output(input.size(), std::vector<float>(input.size(), 0));

//     convolve(input, output, kernel);

//     for (auto& row : output) {
//         for (auto& elem : row) {
//             std::cout << elem << " ";
//         }
//         std::cout << std::endl;
//     }



// // std::vector<std::vector<float>> input = {{1, 2, 3}, {4, 5, 6}, {7, 8, 9}};
// //     std::vector<std::vector<float>> kernel = {{1, 1}, {1, 1}};
// //     std::vector<std::vector<float>> output(input.size(), std::vector<float>(input.size(), 0));

//     convolveWithPadding(input, output, kernel);

//     for (auto& row : output){
//         for (auto& elem : row) {
//             std::cout << elem << " ";
//         }
//         std::cout << std::endl;
//     }

    
    
//     // std::vector<std::vector<float>> input = {{1, 2, 3}, {4, 5, 6}, {7, 8, 9}};

//     relu(input);

//     for (auto& row : input) {
//         for (auto& elem : row) {
//             std::cout << elem << " ";
//         }
//         std::cout << std::endl;
//     }

//     std::cout << std::endl;

//     input = {{1, 2, 3}, {4, 5, 6}, {7, 8, 9}};

//     applyTanh(input); // Changed function name to applyTanh

//     for (auto& row : input) {
//         for (auto& elem : row) {
//             std::cout << elem << " ";
//         }
//         std::cout << std::endl;
//     }


//     vector<float> test = {-1,0,3,5} ;
//     printvec(softmax(test)) ;
//     printvec(sigmoid(test)) ;

//     vector<vector<float>> mat = {{12,20,30,0},{8,12,2,0},{34,70,37,4},{112,180,25,12}};
//     vector<vector<vector<float>>> ou = maxpooling(mat,2);
//     printmatrix(ou[0]) ;
//     printmatrix(ou[1]) ;
    
//     return 0;



    

    
// }








