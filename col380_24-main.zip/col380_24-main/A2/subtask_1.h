#ifndef SUBTASK_1_H
#define SUBTASK_1_H

#include <vector>

std::vector<std::vector<float>> maxpooling(std::vector<std::vector<float>> matrix, int stride);
void printmatrix(std::vector<std::vector<float>> matrix);
std::vector<float> softmax(std::vector<float> vec);
std::vector<float> sigmoid(std::vector<float> vec);
void printvec(std::vector<float> vec);
void convolve(std::vector<std::vector<float>> input, std::vector<std::vector<float>>& output,std::vector<std::vector<float>> kernel);
void convolveWithPadding(const std::vector<std::vector<float>>& input, std::vector<std::vector<float>>& output, const std::vector<std::vector<float>>& kernel);
void relu(std::vector<std::vector<float>>& input);
void applyTanh(std::vector<std::vector<float>>& input);

#endif
