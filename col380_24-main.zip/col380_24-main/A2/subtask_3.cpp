#include <iostream>
#include <cstdlib>
#include <fstream>
#include <sstream>
#include <random>

#include "subtask_1.h"


using namespace std;




void add_bias(vector<vector<float>>& input,float bias){
    for (int i=0;i<input.size();i++){
        for(int j=0;j<input[0].size();j++){
            input[i][j]+=bias;
        }
    }
}
int main(){
    //read the data for convolution layer 1
    string conv1_path="trained_weights/conv1.txt";
    vector<vector<vector<float>>> kernel1(20,vector<vector<float>>(5,vector<float>(5,0.0f)));

    vector<float> bias1(20,0.0f);
    ifstream file(conv1_path);
    if (file.is_open()){
        float num;
        int i=0;
        
        while(file>>num){
            // cout<<num<<endl;
            if (i>=500){
                 bias1[i-500]=num;
            }
            else{
                int j=i/25;
                int k=i-25*j;
                kernel1[j][k/5][k%5]=num;

            }
            i++;
        }
        file.close();
        
    }
    else{
        cout<<"unable to open the file"<<endl;
    }
    // for (int i=0;i<20;i++){
    //     for(int j=0;j<5;j++){
    //         for(int k=0;k<5;k++){
    //             cout<<kernel1[i][j][k]<<" ";
    //         }
    //         cout<<endl;
    //     }
    //     cout<<endl;
    //     cout<<bias1[i]<<endl;
    //     cout<<endl;
    // }
    vector<vector<float>> input(28,vector<float>(28,0.0f));
    //read the input image data
    string img_path="test_txt/000016-num9.txt";
    ifstream image(img_path);
    if (image.is_open()){
        float num;
        int i=0;
        while(image>>num){
            input[i/28][i%28]=num;
            
            // cout<<num<<" , "<<input[i/28][i%28]<<": "<<i/28<<","<<i%28 <<endl;
            i++;
        }
        image.close();
    }
    else{
        cout<<"Unable to open the image"<<endl;
    }
    // cout<<input.size()<<" "<<input[0].size()<<endl;
    // for(int i=0;i<28;i++){
    //     for(int j=0;j<28;j++){
    //         cout<<input[i][j]<<" ";
    //     }
    //     cout<<endl;
    // }
    vector<vector<vector<float>>> output1(20,vector<vector<float>>(24,vector<float>(24,0.0f)));

    //--------------Convolution Layer1--------------//
    for(int i=0;i<20;i++){
        convolve(input,output1[i],kernel1[i]);
        add_bias(output1[i],bias1[i]);
        
        // for(int j=0;j<24;j++){
        //     for(int k=0;k<24;k++){
        //         cout<<output1[i][j][k]<<" ";
        //     }
        //     cout<<endl;
        // }
        // cout<<endl;
    }

    vector<vector<vector<float>>> input2(20);
    //-----------------Pooling layer 1----------------//
    for(int i=0;i<20;i++){
        input2[i]=maxpooling(output1[i],2);
        // cout<<input2[i].size()<<" "<<input2[i][0].size()<<endl;
    }
    

    string conv2_path="trained_weights/conv2.txt";
    vector<vector<vector<vector<float>>>> kernel2(50,vector<vector<vector<float>>>(20,vector<vector<float>>(5,vector<float>(5,0.0f))));
    vector<float> bias2(50,0.0f);
    ifstream file2(conv2_path);
    if (file2.is_open()){
        float num;
        int i=0;
        
        while(file2>>num){
            // cout<<num<<endl;
            if (i>=25000){
                 bias2[i-25000]=num;
            }
            else{
                int filter=i/500;
                int j=(i%500)/25;
                int k=(i%500)-25*j;
                // cout<<filter<<" "<<j<<" "<<k/5<<" "<<k%5<<endl;
                kernel2[filter][j][k/5][k%5]=num;

            }
            i++;
        }
        // cout<<"end at:"<<i<<endl;
        file2.close();
        
    }
    else{
        cout<<"unable to open the file"<<endl;
    }
    // for(int a=0;a<50;a++){
    //     for (int i=0;i<20;i++){
    //     for(int j=0;j<5;j++){
    //         for(int k=0;k<5;k++){
    //             cout<<kernel2[a][i][j][k]<<" ";
    //         }
    //         cout<<endl;
    //     }
    //     cout<<endl;
    //     cout<<bias2[a]<<endl;
    //     cout<<endl;
    //     if (a>=0) break;
    // }
    // }
    vector<vector<vector<float>>> output_conv2(50,vector<vector<float>>(8,vector<float>(8,0.0f)));
    //------------------------Convolution Layer 2---------------//
    for(int i=0;i<50;i++){
        for(int j=0;j<20;j++){
            vector<vector<float>> temp(8,vector<float>(8,0.0f));
            convolve(input2[j],temp,kernel2[i][j]);
            for(int a=0;a<8;a++){
                for(int b=0;b<8;b++){
                    output_conv2[i][a][b]+=temp[a][b];
                }
            }
        }
        add_bias(output_conv2[i],bias2[i]);
        // cout<<"---------------"<<i<<"---------"<<endl;
        // for(int a=0;a<8;a++){
        //     for(int b=0;b<8;b++){
        //         cout<<output_conv2[i][a][b]<<" ";
        //     }
        //     cout<<endl;
        // }
        // cout<<endl;
    }
    vector<vector<vector<float>>> input_fc1(50);

    //-------------------Pooling layer 2----------------//
    for(int i=0;i<50;i++){
        input_fc1[i]=maxpooling(output_conv2[i],2);
        // cout<<input_fc1[i].size()<<" "<<input_fc1[i][0].size()<<endl;//check dimensions
    }
    
    string fc1_path="trained_weights/fc1.txt";
    vector<vector<vector<vector<float>>>> kernel3(500,vector<vector<vector<float>>>(50,vector<vector<float>>(4,vector<float>(4,0.0f))));
    vector<float> bias3(500,0.0f);
    ifstream file3(fc1_path);
    if (file3.is_open()){
        float num;
        int i=0;
        
        while(file3>>num){
            // cout<<i<<" : "<<num<<endl;
            if (i>=400000){
                 bias3[i-400000]=num;
            }
            else{
                int filter=i/800;
                int j=(i%800)/16;
                int k=(i%800)-16*j;
                // cout<<filter<<" "<<j<<" "<<k/4<<" "<<k%4<<endl;
                kernel3[filter][j][k/4][k%4]=num;

            }
            i++;
        }
        cout<<"end at:"<<i<<endl;
        file3.close();
        
    }
    else{
        cout<<"unable to open the file"<<endl;
    }
    
    // for(int a=0;a<500;a++){
    //     for (int i=0;i<50;i++){
    //     for(int j=0;j<4;j++){
    //         for(int k=0;k<4;k++){
    //             cout<<kernel3[a][i][j][k]<<" ";
    //         }
    //         cout<<endl;
    //     }
    //     cout<<endl;
    //     cout<<bias3[a]<<endl;
    //     cout<<endl;
    //     if (i>=0) break;
    // }
    // if (a>=0) break;
    // }
    
    vector<vector<vector<float>>> output_fc1(500,vector<vector<float>>(1,vector<float>(1,0.0f)));
    //------------------------Fully Connected Layer 1---------------//
    for(int i=0;i<500;i++){
        for(int j=0;j<50;j++){
            vector<vector<float>> temp(1,vector<float>(1,0.0f));
            convolve(input_fc1[j],temp,kernel3[i][j]);
            // for(int a=0;a<1;a++){
            //     for(int b=0;b<1;b++){
                    output_fc1[i][0][0]+=temp[0][0];
            //     }
            // }
        }

        add_bias(output_fc1[i],bias3[i]);
        relu(output_fc1[i]);
        // cout<<"---------------"<<i<<"---------"<<endl;
        // for(int a=0;a<1;a++){
        //     for(int b=0;b<1;b++){
        //         cout<<output_fc1[i][a][b]<<" ";
        //     }
        //     cout<<endl;
        // }
        // cout<<endl;
    }
    
    string fc2_path="trained_weights/fc2.txt";
    vector<vector<vector<vector<float>>>> kernel4(10,vector<vector<vector<float>>>(500,vector<vector<float>>(1,vector<float>(1,0.0f))));
    vector<float> bias4(10,0.0f);
    ifstream file4(fc2_path);
    if (file4.is_open()){
        float num;
        int i=0;
        
        while(file4>>num){
            // cout<<i<<" : "<<num<<endl;
            if (i>=5000){
                 bias4[i-5000]=num;
            }
            else{
                int filter=i/500;
                int j=(i%500);
                // int k=(i%0)-16*j;
                // cout<<filter<<" "<<j<<" "<<0<<" "<<0<<endl;
                kernel4[filter][j][0][0]=num;

            }
            i++;
        }
        cout<<"end at:"<<i<<endl;
        file4.close();
        
    }
    else{
        cout<<"unable to open the file"<<endl;
    }
    vector<vector<vector<float>>> output_fc2(10,vector<vector<float>>(1,vector<float>(1,0.0f)));
    //------------------------Fully Connected Layer 1---------------//
    for(int i=0;i<10;i++){
        for(int j=0;j<500;j++){
            vector<vector<float>> temp(1,vector<float>(1,0.0f));
            convolve(output_fc1[j],temp,kernel4[i][j]);
            // for(int a=0;a<1;a++){
            //     for(int b=0;b<1;b++){
                    output_fc2[i][0][0]+=temp[0][0];
            //     }
            // }
        }

        add_bias(output_fc2[i],bias4[i]);
        // relu(output_fc2[i]);
        // cout<<"---------------"<<i<<"---------"<<endl;
        // for(int a=0;a<1;a++){
        //     for(int b=0;b<1;b++){
                cout<<i<<" : "<<output_fc1[i][0][0]<<endl;
        //     }
        //     cout<<endl;
        // }
        // cout<<endl;
    }
    return 0;
}
